<?php $__currentLoopData = $contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th scope="row"><?php echo e($contributor->id); ?></th>
        <td><?php echo e($contributor->getFio()); ?></td>
        <td><?php echo e($contributor->city); ?></td>
        <td>
            <?php echo e($contributor->getCountry->name); ?>

        </td>
        <td>
            <?php echo e($contributor->sum); ?> ₽
        </td>
        <td>
            <a href="<?php echo e(route('certificate.download', $contributor->Certificate->id)); ?>" class="btn btn-info">Скачать сертификат</a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/ajax/admin/index.blade.php ENDPATH**/ ?>