<?php $__env->startSection('title', 'Добавить волонтера'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <form class="row g-3" action="<?php echo e(route('admin.volunteers.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label for="inputNumber" class="col-sm-2 col-form-label">Фото</label>
            <div class="col-md-12"><input class="form-control" type="file" name="photo" id="formFile"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="name" placeholder="Имя" value="<?php echo e(old('name')); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="lastname" placeholder="Фамилия" value="<?php echo e(old('lastname')); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="patronymic" placeholder="Отчество" value="<?php echo e(old('patronymic')); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="city" placeholder="Город" value="<?php echo e(old('city')); ?>"></div>

            <div class="col-md-12"><input type="text" class="form-control" name="whatsapp" placeholder="whatsapp | https://wa.me/7XXXXXXXXXX" value="<?php echo e(old('whatsapp')); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="telegram" placeholder="telegram | https://t.me/XXXXXXXXX" value="<?php echo e(old('telegram')); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="email" placeholder="email | mail@mail.ru" value="<?php echo e(old('email')); ?>"></div>

            <div class="col-md-12"><input type="password" class="form-control" name="password" placeholder="Пароль" value=""></div>

            <div class="col-md-12"><textarea name="note" class="form-control" placeholder="Заметка (необязательно)" id="" cols="10" rows="3"><?php echo e(old('note')); ?></textarea></div>

            <div class="text-center">
                <button type="submit" class="btn btn-primary">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/admin/volunteers/create.blade.php ENDPATH**/ ?>