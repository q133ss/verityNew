<?php $__env->startSection('title', 'Профиль'); ?>
<?php $__env->startSection('meta'); ?>
    <link rel="stylesheet" href="/assets/css/profile.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="containers">
        <div class="profile-wrap">
            <?php echo $__env->make('includes.profile.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="profile-content">
                <?php if($errors->any()): ?>
                    <span class="for_volunteers-plus__item-d" style="color:#f00; font-weight: 700;"><?php echo e($errors->first()); ?></span>
                <?php endif; ?>

                <?php if(session()->has('success')): ?>
                    <span class="for_volunteers-plus__item-d" style="color:#446a4c; font-weight: 700;"><?php echo e(session()->get('success')); ?></span>
                <?php endif; ?>
                <form action="<?php echo e(route('profile.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Фамилия</div>
                        <input class="custom-input" value="<?php echo e($user->lastname); ?>" name="lastname" placeholder="Фамилия">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Имя</div>
                        <input class="custom-input" value="<?php echo e($user->name); ?>" name="name" placeholder="Имя">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Отчество</div>
                        <input class="custom-input" value="<?php echo e($user->patronymic); ?>" name="patronymic" placeholder="Отчество">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Город</div>


                        <select name="city" id="" class="js-data-example-ajax custom-input">
                            <option value="<?php echo e($user->city); ?>"><?php echo e($user->city); ?></option>
                        </select>

                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Email</div>
                        <input class="custom-input" value="<?php echo e($user->getSocial('email')); ?>" name="email" placeholder="Email">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Telegram</div>
                        <input class="custom-input" value="<?php echo e($user->getSocial('telegram')); ?>" name="telegram" placeholder="Telegram">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Whatsapp</div>
                        <input class="custom-input" value="<?php echo e($user->getSocial('whatsapp')); ?>" name="whatsapp" placeholder="Whatsapp">
                    </div>

                    <button class="header__banner-b save-btn" type="submit">Сохранить</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $('#country_input').select2({
            minimumInputLength: 3, // only start searching when the user has input 3 or more characters
            language: {
                inputTooShort: function () {
                    return "Введите минимум 3 символа";
                },
                noResults: function () {
                    return 'Ничего не найдено';
                }
            }
        });
    </script>

    <script>
        $(document).ready(function() {
            $(".js-data-example-ajax").select2({
                ajax: {
                    url: function (params) {
                        return "http://geodb-free-service.wirefreethought.com/v1/geo/cities?offset=0&namePrefix="+ params.term +"&languageCode=ru";
                    },
                    dataType: 'json',
                    quietMillis: 100,
                    processResults: function(data) {
                        return {
                            results: $.map(data.data, function(item) {
                                console.log(typeof(item))
                                return {
                                    'value': item.id,
                                    'id': item.id,
                                    'text': item.name
                                };
                            })
                        };
                    }
                }
            });
        });

    </script>

    <style>
        .recom-btn{
            background-color:#d5ba64;
            cursor: pointer;
            border-radius: 50px;
            padding: 3px 15px 0 15px;
            color: #ffffff;
        }
    </style>

    <script>
        function changeSum(sum){
            $('#sum-input').val(sum)
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/profile/index.blade.php ENDPATH**/ ?>