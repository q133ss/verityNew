<?php $__env->startSection('title', 'Вход'); ?>
<?php $__env->startSection('content'); ?>
    <div class="donate-form">
        <div class="donate-form__banner"> <img src="/assets/svg/donate/bg.svg"></div>
        <div class="containers">
            <form action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="donate-form__wrapper">
                    <div class="donate-form__t">Вход</div>
                    <?php if($errors->any()): ?>
                        <span class="for_volunteers-plus__item-d" style="color:#f00; font-weight: 700;"><?php echo e($errors->first()); ?></span>
                    <?php endif; ?>
                    <div class="donate-form__blocks">
                        <div class="donate-form__item">
                            <div class="donate-form__item-l">Введите вашу почту</div>
                            <input class="custom-input" value="<?php echo e(old('email')); ?>" name="email" placeholder="mail@mail.ru">
                        </div>
                        <div class="donate-form__item">
                            <div class="donate-form__item-l">Введите ваш пароль</div>
                            <input class="custom-input" value="" type="password" name="password" placeholder="*********">
                        </div>
                    </div>
                    <button type="submit" class="donate-form__button">Войти</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/auth/login.blade.php ENDPATH**/ ?>