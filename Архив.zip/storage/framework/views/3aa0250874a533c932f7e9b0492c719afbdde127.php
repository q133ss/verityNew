<?php $__env->startSection('title', 'Профиль'); ?>
<?php $__env->startSection('meta'); ?>
    <link rel="stylesheet" href="/assets/css/profile.css">
    <style>
        .btn-info{
            color: #0000ff;
        }
        .btn-warning{
            color: #d5ba64;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="containers">
        <div class="profile-wrap">
            <?php echo $__env->make('includes.profile.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="profile-content">
                <?php if($errors->any()): ?>
                    <span class="for_volunteers-plus__item-d" style="color:#f00; font-weight: 700;"><?php echo e($errors->first()); ?></span>
                <?php endif; ?>

                <?php if(session()->has('success')): ?>
                    <span class="for_volunteers-plus__item-d" style="color:#446a4c; font-weight: 700;"><?php echo e(session()->get('success')); ?></span>
                <?php endif; ?>

                <div class="contributors__list">
                    <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="contributors__item" style="grid-template-columns:1fr 1fr;">
                            <div class="contributors__item-d"><?php echo e($certificate->number); ?></div>
                            <div class="contributors__item-n">
                                <a href="<?php echo e(route('certificate.show',$certificate->id)); ?>" class="btn btn-info">Смотреть</a>
                                <a href="<?php echo e(route('certificate.download', $certificate->id)); ?>" class="btn btn-warning">Скачать</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/profile/myCertificates.blade.php ENDPATH**/ ?>