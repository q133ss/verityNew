<?php $__env->startSection('title', 'Оформить сертификат'); ?>
<?php $__env->startSection('meta'); ?>
    <link rel="stylesheet" href="/assets/css/profile.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="containers">
        <div class="profile-wrap">
            <?php echo $__env->make('includes.profile.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="profile-content">
                <form action="<?php echo e(route('contributors.payment')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="">
                        <?php if($errors->any()): ?>
                            <span class="for_volunteers-plus__item-d" style="color:#f00; font-weight: 700;"><?php echo e($errors->first()); ?></span>
                        <?php endif; ?>
                        <div class="">
                            <div class="donate-form__item">
                                <div class="donate-form__item-l">Введите фамилию</div>
                                <input class="custom-input" value="<?php echo e(old('lastname')); ?>" name="lastname" placeholder="Фамилия">
                            </div>
                            <div class="donate-form__item">
                                <div class="donate-form__item-l">Введите имя</div>
                                <input class="custom-input" value="<?php echo e(old('name')); ?>" name="name" placeholder="Имя">
                            </div>
                            <div class="donate-form__item">
                                <div class="donate-form__item-l">Введите Отчество </div>
                                <input class="custom-input" value="<?php echo e(old('patronymic')); ?>" name="patronymic" placeholder="Отчество">
                            </div>
                            <div class="donate-form__item">
                                <div class="donate-form__item-l">Введите номер телефона</div>
                                <label class="custom-input-phone__label"><img class="custom-input-phone__icon" src="/assets/svg/components/rus.svg">
                                    <input class="custom-input-phone__input" value="<?php echo e(old('phone')); ?>" id="phone__mask" name="phone" placeholder="+7">
                                </label>
                            </div>
                            <div class="donate-form__item">
                                <div class="donate-form__item-l">Введите почту</div>
                                <input class="custom-input" value="<?php echo e(old('email')); ?>" name="email" placeholder="mail@mail.ru">
                            </div>
                            <div class="donate-form__item">
                                <div class="donate-form__item-l">Выберите страну</div>
                                <select name="country_id" class="custom-input" id="country_input">
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="donate-form__item">
                                <div class="donate-form__item-l">Введите регион</div>
                                
                                
                                <select name="city" id="" class="js-data-example-ajax custom-input">
                                    <option value="Москва">Москва</option>
                                </select>

                            </div>
                            <input type="hidden" name="recommender_id" value="<?php echo e(Auth()->id()); ?>">
                            <div class="donate-form__item">
                                <div class="donate-form__item-l">Введите сумму пожертвования</div>
                                <label class="custom-input-rub__label">
                                    <div class="custom-input-rub__text">₽</div>
                                    <input class="custom-input-rub__input" id="sum-input" value="<?php echo e(old('sum')); ?>" name="sum" placeholder="">
                                </label>

                                <div class="recom-price">
                                    <span class="recom-btn" onclick="changeSum(1000)">1000</span>
                                    <span class="recom-btn" onclick="changeSum(3000)">3000</span>
                                    <span class="recom-btn" onclick="changeSum(5000)">5000</span>
                                </div>

                            </div>
                        </div>
                        <div class="donate-form__checkboxs">
                            <div class="checkbox">
                                <input class="checkbox__input" type="checkbox" id="1">
                                <label class="checkbox__label" for="1">Согласен с политикой обработки персональных данных, договором офертой  и условиями использования</label>
                            </div>
                            <div class="checkbox">
                                <input class="checkbox__input" type="checkbox" id="2">
                                <label class="checkbox__label" for="2">Согласен с политикой обработки персональных данных, правилами предоставления услуг по подписке, офертой рекуррентных платежей, договором-офертой и условиями использования</label>
                            </div>
                        </div>
                        <button type="submit" class="donate-form__button">Пожертвовать</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $('#country_input').select2({
            minimumInputLength: 3, // only start searching when the user has input 3 or more characters
            language: {
                inputTooShort: function () {
                    return "Введите минимум 3 символа";
                },
                noResults: function () {
                    return 'Ничего не найдено';
                }
            }
        });
    </script>

    <script>
        $(document).ready(function() {
            $(".js-data-example-ajax").select2({
                ajax: {
                    url: function (params) {
                        return "http://geodb-free-service.wirefreethought.com/v1/geo/cities?offset=0&namePrefix="+ params.term +"&languageCode=ru";
                    },
                    dataType: 'json',
                    quietMillis: 100,
                    processResults: function(data) {
                        return {
                            results: $.map(data.data, function(item) {
                                console.log(typeof(item))
                                return {
                                    'value': item.id,
                                    'id': item.id,
                                    'text': item.name
                                };
                            })
                        };
                    }
                }
            });
        });

    </script>

    <style>
        .recom-btn{
            background-color:#d5ba64;
            cursor: pointer;
            border-radius: 50px;
            padding: 3px 15px 0 15px;
            color: #ffffff;
        }
    </style>

    <script>
        function changeSum(sum){
            $('#sum-input').val(sum)
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/profile/certificate.blade.php ENDPATH**/ ?>