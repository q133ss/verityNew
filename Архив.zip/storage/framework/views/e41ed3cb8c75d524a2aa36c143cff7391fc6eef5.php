<?php $__env->startSection('title', 'Волонтер'); ?>
<?php $__env->startSection('content'); ?>
    <p>
        Колличество проданных сертификатов: <?php echo e($volunteer->getStat('donated') ?? 0); ?> <br>
        Сумма на которую проданны сертификаты: <?php echo e($volunteer->getStat('earnings') ?? 0); ?>

    </p>
    <p>
        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
            Список волонтеров
        </button>
    </p>
    <div class="collapse" id="collapseExample">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">ФИО</th>
                <th scope="col">Город</th>
                <th scope="col">Страна</th>
                <th scope="col">Сумма</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody class="contributors__list">
            <?php $__currentLoopData = $volunteer->getContributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($contributor->id); ?></th>
                    <td><?php echo e($contributor->getFio()); ?></td>
                    <td><?php echo e($contributor->city); ?></td>
                    <td>
                        <?php echo e($contributor->getCountry->name); ?>

                    </td>
                    <td>
                        <?php echo e($contributor->sum); ?> ₽
                    </td>
                    <td>
                        <a href="<?php echo e(route('certificate.download', $contributor->Certificate->id)); ?>" class="btn btn-info">Скачать сертификат</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/admin/volunteers/show.blade.php ENDPATH**/ ?>