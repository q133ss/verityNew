<?php $__env->startSection('title', 'Мои жертвователи'); ?>
<?php $__env->startSection('meta'); ?>
    <link rel="stylesheet" href="/assets/css/profile.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="containers">
        <div class="profile-wrap">
            <?php echo $__env->make('includes.profile.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="profile-content">
                <div class="contributors__list">
                    <?php $__currentLoopData = $contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="contributors__item" style="">
                        <div class="contributors__item-d"><?php echo e($key+1); ?></div>
                        <div class="contributors__item-n"><?php echo e($contributor->getFio()); ?></div>
                        <div class="contributors__item-p"><?php echo e($contributor->sum); ?> ₽</div>
                        <div class="contributors__item-c"><?php echo e($contributor->getCountry->name); ?>, <?php echo e($contributor->city); ?></div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/profile/contributors.blade.php ENDPATH**/ ?>