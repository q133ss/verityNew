<div class="sidebar">
    <nav>
        <div class="menu-item"><a href="<?php echo e(route('profile.index')); ?>" class="nav-item">Мой профиль</a></div>
        <?php if(Auth()->user()->is_volunteer): ?>
        <div class="menu-item"><a href="<?php echo e(route('profile.contributors')); ?>" class="nav-item">Мои жертвователи</a></div>
        <div class="menu-item"><a href="<?php echo e(route('profile.statistic')); ?>" class="nav-item">Статистика</a></div>
        <div class="menu-item"><a href="<?php echo e(route('profile.certificate')); ?>" class="nav-item">Оформить сертефикат</a></div>
        <?php elseif(!Auth()->user()->is_volunteer && !Auth()->user()->is_admin): ?>
            <div class="menu-item"><a href="<?php echo e(route('profile.contributor.certificate')); ?>" class="nav-item">Мои сертификаты</a></div>
        <?php endif; ?>
        <?php if(Auth()->user()->is_admin): ?>
        <div class="menu-item"><a href="<?php echo e(route('admin.index')); ?>" class="nav-item">Панель администратора</a></div>
        <?php endif; ?>
        <div class="menu-item"><a href="/logout" class="nav-item">Выйти</a></div>
    </nav>
</div>
<?php /**PATH /home/b/bpump/verity.bpump.ru/public_html/resources/views/includes/profile/menu.blade.php ENDPATH**/ ?>