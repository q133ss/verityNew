<?php $__env->startSection('title', 'Рекомендатели'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <a href="<?php echo e(route('admin.recommend.create')); ?>" class="btn btn-info">Добавить</a>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Имя</th>
                <th scope="col">Город</th>
                <th scope="col">Действия</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $recommends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($recommend->id); ?></th>
                    <td><?php echo e($recommend->name); ?></td>
                    <td><?php echo e($recommend->city); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.recommend.edit', $recommend->id)); ?>" class="btn btn-warning">Изменить</a>
                        <form action="<?php echo e(route('admin.recommend.destroy', $recommend->id)); ?>" method="POST" style="display: inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger" type="submit">Удалить</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/b/bpump/verity.bpump.ru/public_html/resources/views/admin/recommends/index.blade.php ENDPATH**/ ?>