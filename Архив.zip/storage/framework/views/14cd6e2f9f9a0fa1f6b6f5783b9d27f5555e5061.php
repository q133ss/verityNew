<?php $__env->startSection('title', 'Волонтеры'); ?>
<?php $__env->startSection('meta'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js?_v=20221017195015" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <a href="<?php echo e(route('admin.volunteers.create')); ?>" class="btn btn-info">Добавить</a>
        <a href="<?php echo e(route('admin.volunteers.block')); ?>" class="btn btn-primary">Заблокированные</a>

        <div class="row mt-3">
            <div class="col-md-3">
                <select name="#" class="form-select" id="#" onchange="sort($(this).val())">
                    <option value="lastname">Сортировка по фамилии</option>
                    <option value="name">Сортировка по имени</option>
                    <option value="patronymic">Сортировка по отчеству</option>
                </select>
            </div>

            <div class="col-md-3">
                <input type="text" class="form-control" id="address" placeholder="Поиск по ФИО" oninput="search($(this).val())" required="">
            </div>

            <div class="col-md-3">
                <input type="text" class="form-control" id="address" placeholder="Поиск по региону" oninput="searchCity($(this).val())" required="">
            </div>
        </div>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">ФИО</th>
                <th scope="col">Город</th>
                <th scope="col">Соц.сети</th>
                <th scope="col">Действия</th>
            </tr>
            </thead>
            <tbody class="volunteers-recom__list">
            <?php $__currentLoopData = $volunteers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $volunteer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($volunteer->id); ?></th>
                    <td><?php echo e($volunteer->getFio()); ?></td>
                    <td><?php echo e($volunteer->city); ?></td>
                    <td>
                        <?php $__currentLoopData = $volunteer->getSocials(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($social); ?>"><?php echo e($key); ?></a> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.volunteers.edit', $volunteer->id)); ?>" class="btn btn-warning">Изменить</a>
                        <a href="<?php echo e(route('admin.volunteers.show', $volunteer->id)); ?>" class="btn btn-info">Смотреть</a>
                        <form action="<?php echo e(route('admin.volunteers.destroy', $volunteer->id)); ?>" style="display:inline" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Заблокировать</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function sort(field){
            $.ajax({
                url: '/admin/volunteers/sort/'+field,
                type: "POST",
                data: {
                    field:field
                },
                headers:{
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: (data) => {
                    $('.volunteers-recom__list').html(data)
                },
                error: function(request, status, error) {
                    //console.log(statusCode = request.responseText);
                }
            })
        }

        function search(request){
            $.ajax({
                url: '/admin/volunteers/search/'+request,
                type: "POST",
                data: {
                    request:request
                },
                headers:{
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: (data) => {
                    $('.volunteers-recom__list').html(data)
                },
                error: function(request, status, error) {
                    console.log(statusCode = request.responseText);
                }
            })
        }

        function searchCity(city){
            $.ajax({
                url: '/admin/volunteers/search/city/'+city,
                type: "POST",
                headers:{
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: (data) => {
                    $('.volunteers-recom__list').html(data)
                },
                error: function(request, status, error) {
                    console.log(statusCode = request.responseText);
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/admin/volunteers/index.blade.php ENDPATH**/ ?>