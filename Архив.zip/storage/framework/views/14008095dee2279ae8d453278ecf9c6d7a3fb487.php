<?php $__env->startSection('title', 'Заблокированные волонтеры'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <a href="<?php echo e(route('admin.volunteers.index')); ?>" class="btn btn-info">Назад</a>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">ФИО</th>
                <th scope="col">Город</th>
                <th scope="col">Соц.сети</th>
                <th scope="col">Действия</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $volunteers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $volunteer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($volunteer->id); ?></th>
                    <td><?php echo e($volunteer->getFio()); ?></td>
                    <td><?php echo e($volunteer->city); ?></td>
                    <td>
                        <?php $__currentLoopData = $volunteer->getSocials(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($social); ?>"><?php echo e($key); ?></a> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.volunteers.edit', $volunteer->id)); ?>" class="btn btn-warning">Изменить</a>
                        <form action="<?php echo e(route('admin.volunteers.unblock', $volunteer->id)); ?>" style="display:inline" method="POST">
                            <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success">Разблокировать</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/admin/volunteers/block.blade.php ENDPATH**/ ?>