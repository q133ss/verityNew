<?php

namespace App\Http\Controllers;

use App\Models\Certificate;
use App\Models\Contributor;
use Illuminate\Http\Request;

class CertificateController extends Controller
{
    public function show($id)
    {
        $certificate = Certificate::findOrFail($id);
        return view('certificate', compact('certificate'));
    }
}
