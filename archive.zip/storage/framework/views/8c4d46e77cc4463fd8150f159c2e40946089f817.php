<?php $__currentLoopData = $volunteers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter => $letterVolunteer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="volunteers-recom__list-i">
        <div class="volunteers-recom__list-t"><?php echo e($letter); ?></div>
        <div class="volunteers-recom__list-peoples">
            <?php $__currentLoopData = $letterVolunteer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $volunteer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cardUser">
                    <div class="cardUser__photo"> <picture><source srcset="/assets/img/volunteers/people.webp" type="image/webp"><img src="/assets/img/volunteers/people.png"></picture></div>
                    <div class="cardUser__content">
                        <div class="cardUser__content-n"><?php echo e($volunteer->getFio()); ?></div>
                        <div class="cardUser__content-j"><?php echo e($volunteer->city); ?></div>
                        <div class="cardUser__content-socials"><a class="cardUser__content-s" href="/"> <picture><source srcset="/assets/img/volunteers/whatsapp.webp" type="image/webp"><img src="/assets/img/volunteers/whatsapp.png"></picture></a><a class="cardUser__content-s" href="/"> <picture><source srcset="/assets/img/volunteers/telegram.webp" type="image/webp"><img src="/assets/img/volunteers/telegram.png"></picture></a><a class="cardUser__content-s" href="/"> <picture><source srcset="/assets/img/volunteers/mail.webp" type="image/webp"><img src="/assets/img/volunteers/mail.png"></picture></a></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/ajax/volunteers.blade.php ENDPATH**/ ?>