<?php $__env->startSection('title', 'Изменить волонтера'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <form class="row g-3" action="<?php echo e(route('admin.volunteers.update', $volunteer->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="inputNumber" class="col-sm-2 col-form-label">Фото</label>
            <img src="<?php echo e($volunteer->photo); ?>" alt="" width="300px">
            <div class="col-md-12"><input class="form-control" type="file" name="photo" id="formFile"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="name" placeholder="Имя" value="<?php echo e($volunteer->name); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="lastname" placeholder="Фамилия" value="<?php echo e($volunteer->lastname); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="patronymic" placeholder="Отчество" value="<?php echo e($volunteer->patronymic); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="city" placeholder="Город" value="<?php echo e($volunteer->city); ?>"></div>

            <div class="col-md-12"><input type="text" class="form-control" name="whatsapp" placeholder="whatsapp" value="<?php echo e($volunteer->getSocial('whatsapp')); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="telegram" placeholder="telegram" value="<?php echo e($volunteer->getSocial('telegram')); ?>"></div>
            <div class="col-md-12"><input type="text" class="form-control" name="email" placeholder="email" value="<?php echo e($volunteer->getSocial('email')); ?>"></div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\Islam\resources\views/admin/volunteers/edit.blade.php ENDPATH**/ ?>