<?php $__env->startSection('title', 'Вход'); ?>
<?php $__env->startSection('meta'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="donate-main">
        <div class="containers">
            <div class="donate-main__t">Вход</div>
        </div>
    </div>
    <div class="donate-form">
        <div class="donate-form__banner"> <img src="/assets/svg/donate/bg.svg"></div>
        <div class="containers">
            <form action="<?php echo e(route('contributors.payment')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <div class="donate-form__wrapper">
                <div class="donate-form__t">Вход для волонтеров</div>
                <?php if($errors->any()): ?>
                    <span class="for_volunteers-plus__item-d" style="color:#f00; font-weight: 700;"><?php echo e($errors->first()); ?></span>
                <?php endif; ?>
                <div class="donate-form__blocks">
                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Введите телефон</div>
                        <input class="custom-input" value="<?php echo e(old('lastname')); ?>" name="lastname" placeholder="Фамилия">
                    </div>
                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Введите пароль</div>
                        <input class="custom-input" value="" name="password" placeholder="Пароль">
                    </div>
                </div>
                <button type="submit" class="donate-form__button">Войти</button>
            </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/volunteer/login.blade.php ENDPATH**/ ?>