<?php $__env->startSection('title', 'Профиль'); ?>
<?php $__env->startSection('content'); ?>
    <div class="containers">
        <div class="profile-wrap">
            <?php echo $__env->make('includes.profile.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="profile-content">
                <form action="#" method="POST">
                    <?php echo csrf_field(); ?>
                <div class="donate-form__item">
                    <div class="donate-form__item-l">Фамилия</div>
                    <input class="custom-input" value="<?php echo e($user->lastname); ?>" name="lastname" placeholder="Фамилия">
                </div>

                <div class="donate-form__item">
                    <div class="donate-form__item-l">Имя</div>
                    <input class="custom-input" value="<?php echo e($user->name); ?>" name="name" placeholder="Имя">
                </div>

                <div class="donate-form__item">
                    <div class="donate-form__item-l">Отчество</div>
                    <input class="custom-input" value="<?php echo e($user->patronymic); ?>" name="patronymic" placeholder="Отчество">
                </div>

                <div class="donate-form__item">
                    <div class="donate-form__item-l">Город</div>
                    <input class="custom-input" value="<?php echo e($user->city); ?>" name="city" placeholder="Город">
                </div>

                <div class="donate-form__item">
                    <div class="donate-form__item-l">Email</div>
                    <input class="custom-input" value="<?php echo e($user->getSocial('email')); ?>" name="email" placeholder="Email">
                </div>

                <div class="donate-form__item">
                    <div class="donate-form__item-l">Telegram</div>
                    <input class="custom-input" value="<?php echo e($user->getSocial('telegram')); ?>" name="telegram" placeholder="Telegram">
                </div>

                <div class="donate-form__item">
                    <div class="donate-form__item-l">Whatsapp</div>
                    <input class="custom-input" value="<?php echo e($user->getSocial('whatsapp')); ?>" name="whatsapp" placeholder="Whatsapp">
                </div>

                <button class="header__banner-b save-btn" type="submit">Сохранить</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <style>
        .profile-wrap{
            display: flex;
            gap: 30px;
            margin: 35px 0 35px 0;
            min-height: 400px;
        }

        .sidebar{
            box-shadow: 0 0 60px rgba(0,0,0,.1);
            border-radius: 15px;
            background-color: #ffffff;
            padding: 30px;
            width: 300px;
        }

        .profile-content{
            box-shadow: 0 0 60px rgba(0,0,0,.1);
            border-radius: 15px;
            background-color: #ffffff;
            padding: 30px;
            width: 100%;
        }

        .menu-item{
            margin-bottom: 10px;
            font-family: "NunitoSans";
            font-weight: 400;
        }

        .menu-item::after{
            content: "";
            width: 100%;
            height: 4px;
            display: block;
            background: #ff8743;
            border-radius: 10px;
            opacity: 0;
        }

        .menu-item:hover::after{
            opacity: 1;
        }

        .nav-item{
            color:#000000;
        }

        .save-btn{
            margin-top: 30px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/profile.blade.php ENDPATH**/ ?>