<div class="sidebar">
    <nav>
        <div class="menu-item"><a href="<?php echo e(route('profile.index')); ?>" class="nav-item">Мой профиль</a></div>
        <div class="menu-item"><a href="<?php echo e(route('profile.contributors')); ?>" class="nav-item">Мои жертвователи</a></div>
        <div class="menu-item"><a href="<?php echo e(route('profile.statistic')); ?>" class="nav-item">Статистика</a></div>
        <div class="menu-item"><a href="<?php echo e(route('profile.certificate')); ?>" class="nav-item">Оформить сертефикат</a></div>
    </nav>
</div>
<?php /**PATH /Applications/MAMP/htdocs/islam/resources/views/includes/profile/menu.blade.php ENDPATH**/ ?>