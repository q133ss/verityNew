<?php $__currentLoopData = $contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="contributors__item">
        <div class="contributors__item-d"><?php echo e($contributor->id); ?></div>
        <div class="contributors__item-n"><?php echo e($contributor->name); ?></div>
        <div class="contributors__item-p"><?php echo e($contributor->sum); ?> ₽</div>
        <div class="contributors__item-c"><?php echo e($contributor->city); ?></div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/b/bpump/verity.bpump.ru/public_html/resources/views/ajax/contributors.blade.php ENDPATH**/ ?>