@extends('layouts.main')
@section('title', 'Профиль')
@section('meta')
    <link rel="stylesheet" href="/assets/css/profile.css">
@endsection
@section('content')
    <div class="containers">
        <div class="profile-wrap">
            @include('includes.profile.menu')
            <div class="profile-content">
                <form action="#" method="POST">
                    @csrf
                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Фамилия</div>
                        <input class="custom-input" value="{{$user->lastname}}" name="lastname" placeholder="Фамилия">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Имя</div>
                        <input class="custom-input" value="{{$user->name}}" name="name" placeholder="Имя">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Отчество</div>
                        <input class="custom-input" value="{{$user->patronymic}}" name="patronymic" placeholder="Отчество">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Город</div>
                        <input class="custom-input" value="{{$user->city}}" name="city" placeholder="Город">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Email</div>
                        <input class="custom-input" value="{{$user->getSocial('email')}}" name="email" placeholder="Email">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Telegram</div>
                        <input class="custom-input" value="{{$user->getSocial('telegram')}}" name="telegram" placeholder="Telegram">
                    </div>

                    <div class="donate-form__item">
                        <div class="donate-form__item-l">Whatsapp</div>
                        <input class="custom-input" value="{{$user->getSocial('whatsapp')}}" name="whatsapp" placeholder="Whatsapp">
                    </div>

                    <button class="header__banner-b save-btn" type="submit">Сохранить</button>
                </form>
            </div>
        </div>
    </div>
@endsection
