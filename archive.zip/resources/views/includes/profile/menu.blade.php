<div class="sidebar">
    <nav>
        <div class="menu-item"><a href="{{route('profile.index')}}" class="nav-item">Мой профиль</a></div>
        <div class="menu-item"><a href="{{route('profile.contributors')}}" class="nav-item">Мои жертвователи</a></div>
        <div class="menu-item"><a href="{{route('profile.statistic')}}" class="nav-item">Статистика</a></div>
        <div class="menu-item"><a href="{{route('profile.certificate')}}" class="nav-item">Оформить сертефикат</a></div>
    </nav>
</div>
